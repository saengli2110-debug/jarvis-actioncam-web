# Jarvis ActionCam

Mobile-first static web app prototype.

## Features
- Camera preview with front/rear camera selection
- Browser video recording and local download
- Motion sensor sample capture and CSV export (where supported)
- Touch lock with long-press unlock
- Responsive mobile layout

## Run locally
Serve this folder over HTTPS or localhost. Camera and motion sensor APIs generally require a secure context.

## Publish with GitHub Pages
This repository includes `.github/workflows/pages.yml`. In GitHub:
1. Open **Settings → Pages**.
2. Under **Build and deployment**, choose **GitHub Actions** if prompted.
3. Push to the `main` branch. The workflow deploys the repository root.
4. Wait for the Pages workflow to finish, then open the URL shown in Settings → Pages.

## Limitations
This is a browser-based recorder, not a native action camera. Browser backgrounding, device policies, codec support, and storage limits vary. Motion samples are exported separately and are not used for video stabilization.
